Contributing
============

The Symfony Demo application is an open source project. Contributions made by
the community are welcome. Send us your ideas, code reviews, pull requests and
feature requests to help us improve this project. All contributions must follow
the [usual Symfony contribution requirements](https://symfony.com/doc/current/contributing/index.html).
